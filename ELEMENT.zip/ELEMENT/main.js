AOS.init({
    duration: 1000,
});

function show(){

    document.getElementById('sidebar').classList.toggle('active');
}